const app = require('./app');

//Initialize Server
app.listen(3000, () => {
  console.log("Listening on port 3000");
});
